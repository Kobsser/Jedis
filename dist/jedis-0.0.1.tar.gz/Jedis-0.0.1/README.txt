PyJedis makes your job easier
You can use json as a database like 'Redis'
Its syntax is like Redis
enjoy!